/*
  IoT-Based Weather Monitoring System
  Board: NodeMCU ESP8266
  Sensor: BME280 over I2C
  Cloud: ThingSpeak

  STATUS: Starter code for development. Not verified on physical hardware.
  Before use, enter your own Wi-Fi and ThingSpeak credentials.
  Do not publish real credentials in a public repository.
*/

#include <ESP8266WiFi.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
#include <ThingSpeak.h>

// Replace these placeholders locally. Do not commit real secrets.
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

unsigned long THINGSPEAK_CHANNEL_ID = 123456; // Replace with your channel ID
const char* THINGSPEAK_WRITE_API_KEY = "YOUR_WRITE_API_KEY";

constexpr unsigned long UPLOAD_INTERVAL_MS = 20000UL;

WiFiClient client;
Adafruit_BME280 bme;
unsigned long lastUpload = 0;
bool sensorReady = false;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  Serial.print("Connecting to Wi-Fi");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED &&
         millis() - startAttempt < 20000UL) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.print("Wi-Fi connected. IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println();
    Serial.println("Wi-Fi connection failed. Will retry later.");
  }
}

void setup() {
  Serial.begin(115200);
  delay(100);

  // NodeMCU defaults: SDA = D2/GPIO4, SCL = D1/GPIO5.
  Wire.begin(D2, D1);

  sensorReady = bme.begin(0x76);
  if (!sensorReady) {
    sensorReady = bme.begin(0x77);
  }

  if (sensorReady) {
    Serial.println("BME280 detected.");
  } else {
    Serial.println("BME280 not detected. Check wiring and I2C address.");
  }

  connectWiFi();
  ThingSpeak.begin(client);
}

void loop() {
  if (!sensorReady) {
    // Avoid sending invented values when the sensor is missing.
    delay(5000);
    return;
  }

  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  if (millis() - lastUpload >= UPLOAD_INTERVAL_MS) {
    lastUpload = millis();

    float temperatureC = bme.readTemperature();
    float humidityPct = bme.readHumidity();
    float pressureHpa = bme.readPressure() / 100.0F;

    if (isnan(temperatureC) || isnan(humidityPct) || isnan(pressureHpa)) {
      Serial.println("Sensor returned an invalid reading; skipping upload.");
      return;
    }

    Serial.println();
    Serial.println("Weather readings:");
    Serial.print("Temperature: ");
    Serial.print(temperatureC, 2);
    Serial.println(" °C");

    Serial.print("Humidity: ");
    Serial.print(humidityPct, 2);
    Serial.println(" %");

    Serial.print("Pressure: ");
    Serial.print(pressureHpa, 2);
    Serial.println(" hPa");

    if (WiFi.status() == WL_CONNECTED) {
      ThingSpeak.setField(1, temperatureC);
      ThingSpeak.setField(2, humidityPct);
      ThingSpeak.setField(3, pressureHpa);

      int responseCode = ThingSpeak.writeFields(
        THINGSPEAK_CHANNEL_ID,
        THINGSPEAK_WRITE_API_KEY
      );

      if (responseCode == 200) {
        Serial.println("ThingSpeak update successful.");
      } else {
        Serial.print("ThingSpeak update failed. Response code: ");
        Serial.println(responseCode);
      }
    } else {
      Serial.println("Offline: readings were not uploaded.");
    }
  }

  delay(100);
}
